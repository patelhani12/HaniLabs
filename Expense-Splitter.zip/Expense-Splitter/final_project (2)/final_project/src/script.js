function toggleTheme() {
  let html = document.documentElement;
  let btn = document.getElementById("themeBtn");

  html.classList.toggle("dark");
  btn.textContent = html.classList.contains("dark") ? "☀️ Light" : "🌙 Dark";
}

let members = JSON.parse(localStorage.getItem("members")) || [];
let expense = JSON.parse(localStorage.getItem("expense")) || [];
// login user

function loginUser() {
  // Get values
  let username = document.getElementById("username").value;
  let password = document.getElementById("password").value;

  // Validation
  if (username === "" && password === "") {
    alert("Please enter username and password!");
    return;
  }

  if (username === "") {
    alert("Username is required!");
    return;
  }

  if (password === "") {
    alert("Password is required!");
    return;
  }

  let storedName = window.localStorage.getItem("name");
  let storedPassword = window.localStorage.getItem("password");

  // Login check
  if (username === storedName && password === storedPassword) {
    alert("Login successful!✅ Welcome " + username + "👋");
    window.location.href = "main1.html";
    // let displayUser = document.getElementById("displayUser");
    // if(displayUser == "") {
    //   displayUser.innerHTML = "User"
    // } else {
    //   let storedName = localStorage.getItem("name")
    //   displayUser.innerHTML = `${storedName}`
    // }
  } else {
    alert("Invalid username or password.❌");
  }
}

// Go to signup

function goToSignup() {
  window.location.href = "signup.html";
}

// function login() {
//       let user = document.getElementById("username").value;

//       if (user.trim() === "") {
//         alert("Please enter username");
//         return;
//       }

//       localStorage.setItem("user", user);


//       window.location.href = "main1.html";
//     }

// Signup users

function signupUser() {
  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let pass = document.getElementById("password").value;
  let confirm = document.getElementById("confirm").value;

  if (!name || !email || !pass || !confirm) {
    alert("All fields are required!");
    return;
  }

  if (pass !== confirm) {
    alert("Passwords do not match.❌");
    return;
  }

  window.localStorage.setItem("name", name);
  window.localStorage.setItem("email", email);
  window.localStorage.setItem("password", pass);
  window.localStorage.setItem("confirm", confirm);

  alert("Account created successfully!✅");
  window.location.href = "login.html"
}

function showSection(id) {
  console.log("Clicked");
  
  document
    .querySelectorAll(".section-card")
    .forEach((c) => c.classList.add("hidden"));
  document.getElementById(id).classList.remove("hidden");
  console.log("pressed");
}

function addMember() {
  let input = document.getElementById("memberName");
  if (input.value === "") {
    alert("Enter member name");
    return;
  }
  members.push(input.value);
  localStorage.setItem("members", JSON.stringify(members));
  input.value = "";
  renderMembers();
  loadPaidBy();
}

function renderMembers() {
  let list = document.getElementById("memberList");
  list.innerHTML = members
    .map(
      (m) => `
                <li class="bg-gray-100 p-3 rounded-xl flex justify-between items-center text-gray-700 font-medium">
                    ${m}
                </li>`
    )
    .join("");
}

function loadPaidBy() {
  let select = document.getElementById("paidBy");
  select.innerHTML =
    '<option value="" disabled selected>Who paid?</option>' +
    members.map((m) => `<option value="${m}">${m}</option>`).join("");
}

function addExpense() {
  let title = document.getElementById("expenseTitle").value;
  let amount = document.getElementById("expenseAmount").value;
  let date = document.getElementById("expenseDate").value;

  if (!title || !amount || !date) {
    alert("Fill all expense fields");
    return;
  }

  expense.push({ title, amount: Number(amount), date });
  localStorage.setItem("expenses", JSON.stringify(expense));
  updateTotal();
  loadHistory();
  alert("Expense Added");
  showSection("history");
}

function splitExpense() {
  if (expense.length === 0 || members.length === 0) {
    alert("Add members and expense first");
    return;
  }
  let last = expense[expense.length - 1];
  let share = last.amount / members.length;

  let html = `
                <table class="w-full mt-2">
                    <tr class="bg-gray-200"><th class="p-2 text-left">Name</th><th class="p-2 text-right">Must Pay</th></tr>
                    ${members
                      .map(
                        (m) => `
                        <tr class="border-b">
                            <td class="p-2 font-medium">${m}</td>
                            <td class="p-2 text-right text-indigo-600 font-bold">₹${share.toFixed(
                              2
                            )}</td>
                        </tr>`
                      )
                      .join("")}
                </table>`;
  document.getElementById("splitResult").innerHTML = html;
}

function loadHistory() {
  const table = document.getElementById("historyTable");
  table.innerHTML = expense
    .map(
      (e) => `
                <tr class="hover:bg-gray-50 transition-colors">
                    <td class="p-3 font-medium text-gray-700">${e.title}</td>
                    <td class="p-3 text-center text-green-600 font-bold">₹${e.amount}</td>
                    <td class="p-3 text-center text-gray-500 text-sm">${e.date}</td>
                </tr>`
    )
    .join("");
}

function updateTotal() {
  document.getElementById("totalExpense").innerText = expense.reduce(
    (s, e) => s + e.amount,
    0
  );
}

function logout() {
  // agar user data localStorage me hai to clear karo
  localStorage.clear();
  sessionStorage.clear();

  // login page pe redirect
  window.location.href = "login.html";
}

//! Welcome User Logic 
let displayUser = document.getElementById("displayUser");
let storedUserName = localStorage.getItem("name");
if(storedUserName) {
  displayUser.innerHTML = `Welcome, ${storedUserName ?? 'User'}`
}
